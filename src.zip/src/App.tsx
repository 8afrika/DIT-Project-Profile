import React, { useState } from "react";
import "./App.css";
import MainGround from "./components/MainGround";
import Interface from "./Interfaces";


const App = () => {
  const [user, setUser] = useState<User>();

  const getRandomTime = () => {
    return Date.now();
  };

  const getGender = () => {
    return Date.now() % 2 === 0 ? "male" : "female";
  };

  const fetchUsers = async (timestamp: number, gender: string) => {
    let url = `https://fakerapi.it/api/v1/persons?_quantity=1&_gender=${gender}&_seed=${timestamp}`;
    return await fetch(url)
      .then((response) => response.json().then((user) => user.data[0] as User))
      .then((user) => setUser(user));
  };

  const fetchApi = async () => {
    await fetchUsers(getRandomTime(), getGender());
  };

  window.onload = () => fetchApi();

  return (
    <>
      {/* <h1>{user?.firstname}</h1>
      <h1>{user?.lastname}</h1>
      <h1>{user?.email}</h1>
      <h1>{user?.phone}</h1>
      <h1>{user?.birthday}</h1>
      <h1>{user?.address.city}</h1>
      <h1>{user?.address.country}</h1> */}

      <MainGround /> 
    </>
  );
};

export default App;
