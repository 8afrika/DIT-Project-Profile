import React from "react";
import "./MainGround.css";
import flower from "./purple-flower.jpg";
import App from "../App";
import Interface from "../Interfaces";
var FontAwesome = require("react-fontawesome");

function MainGround() {
  return (
    <>
      <div className="bottom-box"></div>
      <div className="bottom-pink"></div>
      <div className="top-box">
        <img src={flower} />
      </div>
      <h1 className="name">Firstname</h1>
      <h1 className="lname">Lastname</h1>
      <FontAwesome
        className="super-crazy-colors"
        name="fa-duotone fa-venus"
        size="3x"
      />
      <div className="multiple-attributes">
        <h2>23/10/1998</h2>
        <h2>Email</h2>
        <h2>Phone</h2>
        <h2>City</h2>
        <h2>Country</h2>
      </div>
    </>
  );
}

export default MainGround;
